#include "System.h"

int main(){
	System sys;
	sys.menu();
	return 0;
}
